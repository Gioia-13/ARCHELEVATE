import React from 'react';
import { Ruler, Users, CheckCircle } from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <header className="relative h-screen">
        <div className="absolute inset-0">
          <img 
            src="https://images.unsplash.com/photo-1487958449943-2429e8be8625?auto=format&fit=crop&q=80"
            alt="Architettura moderna"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black/60"></div>
        </div>
        
        <nav className="relative z-10 flex justify-between items-center px-6 py-4 max-w-7xl mx-auto">
          <div className="text-white text-3xl font-light tracking-wider flex items-center gap-2">
            <span className="font-light">ARCH</span>
            <span className="text-[#0047BB] font-bold">ELEVATE</span>
          </div>
        </nav>

        <div className="relative z-10 flex flex-col justify-center h-full max-w-7xl mx-auto px-6">
          <h1 className="text-white text-4xl md:text-6xl font-light mb-6">
            Tutti i progetti
          </h1>
          <h1 className="text-[#0047BB] text-5xl md:text-8xl font-bold mb-6 drop-shadow-lg">
            di cui hai bisogno
          </h1>
          <p className="text-gray-200 text-xl max-w-2xl">
            Forniamo soluzioni digitali complete per architetti, aiutandoti a mostrare e far crescere il tuo studio nell'era digitale.
          </p>
        </div>
      </header>

      {/* Services Section */}
      <section id="services" className="py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-6">
          <h2 className="text-4xl font-light mb-16 text-center">I Nostri <span className="text-[#0047BB] font-bold">Servizi</span></h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-lg shadow-sm hover:shadow-lg transition-shadow">
              <Ruler className="h-12 w-12 mb-6 text-[#0047BB]" />
              <h3 className="text-xl font-bold mb-4">Design del Sito Web</h3>
              <p className="text-gray-600">Siti web personalizzati che mostrano i tuoi progetti architettonici con visuali straordinarie e navigazione intuitiva.</p>
            </div>
            <div className="bg-white p-8 rounded-lg shadow-sm hover:shadow-lg transition-shadow">
              <Users className="h-12 w-12 mb-6 text-[#0047BB]" />
              <h3 className="text-xl font-bold mb-4">Marketing Digitale</h3>
              <p className="text-gray-600">Strategie mirate per raggiungere potenziali clienti e stabilire la presenza del tuo studio nello spazio digitale.</p>
            </div>
            <div className="bg-white p-8 rounded-lg shadow-sm hover:shadow-lg transition-shadow">
              <CheckCircle className="h-12 w-12 mb-6 text-[#0047BB]" />
              <h3 className="text-xl font-bold mb-4">Gestione Progetti</h3>
              <p className="text-gray-600">Strumenti e piattaforme digitali per ottimizzare il flusso di lavoro dei progetti e la comunicazione con i clienti.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Portfolio Section */}
      <section id="portfolio" className="py-24">
        <div className="max-w-7xl mx-auto px-6">
          <h2 className="text-4xl font-light mb-16 text-center">Progetti in <span className="text-[#0047BB] font-bold">Evidenza</span></h2>
          <div className="grid md:grid-cols-2 gap-8">
            <div className="group relative overflow-hidden rounded-lg">
              <img 
                src="https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&q=80"
                alt="Marketing digitale"
                className="w-full h-[400px] object-cover transition-transform group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <h3 className="text-white text-2xl font-bold">Strategie di Marketing Digitale</h3>
              </div>
            </div>
            <div className="group relative overflow-hidden rounded-lg">
              <img 
                src="https://images.unsplash.com/photo-1432888498266-38ffec3eaf0a?auto=format&fit=crop&q=80"
                alt="Presenza online"
                className="w-full h-[400px] object-cover transition-transform group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <h3 className="text-white text-2xl font-bold">Presenza Online Efficace</h3>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer with P.IVA */}
      <footer className="bg-black py-8">
        <div className="max-w-7xl mx-auto px-6 text-center text-gray-400">
          <p>© 2024 ARCHELEVATE. P.IVA: 04181141203</p>
        </div>
      </footer>
    </div>
  );
}

export default App;